# Elm Syntax Highlight Demo

To run this demo independently, without the need of the package's `src` directory, remove the `, ../src` on line 4-5 of the `elm.json` file and run `elm install pablohirafuji/elm-syntax-highlight`.
