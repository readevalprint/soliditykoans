## prerequisite

```
$ npm install -g browserify http-server
```

## Instruction

Run command

```
$ browserify index.js -o bundle.js
```

Then host this folder in a web server 

```
$ http-server
```

open http://localhost:8080 in a browser and check the result in web console.
